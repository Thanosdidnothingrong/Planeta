# Step 1: Take input from camera
import cv2
#vid = cv2.VideoCapture(0)

#while(True):

    # Capture the video frame by frame
    #ret, frame = vid.read()

    # Display the resulting frame
    #cv2.imshow('Planeta', frame)

    # the 'q' button is set as the quitting button you may use any desire button of your choice
    #if cv2.waitKey(1) & 0xFF == ord('q'):
        #break



# After the loop release the cap object
#vid.release()

# Destroy all the windows
#cv2.destroyAllWindows()












# Step 2: Look for objects in the camera using machine learning
from imageai.Detection import VideoObjectDetection
from imageai.Detection.Custom import CustomObjectDetection
import os

execution_path = os.getcwd()

#detector = VideoObjectDetection()
detector = CustomObjectDetection()
#detector.setModelTypeAsRetinaNet()
detector.setModelTypeAsYOLOv3()
detector.setModelPath( os.path.join(execution_path , "detection_model-ex-009--loss-0018.527.h5"))
detector.setJsonPath(os.path.join(execution_path , "detection_config.json"))
detector.loadModel()
detections = detector.detectObjectsFromImage(input_image=os.path.join(execution_path, "earth1.jfif"), output_image_path=os.path.join(execution_path , "testfinsihed.png"), minimum_percentage_probability=20)

#print(detections)
highest = 0
for detection in detections:
    print(detection["name"] + " : ", detection["percentage_probability"], " : ", detection["box_points"])
    if detection["percentage_probability"] > highest:
        planet_identified = detection["name"]




















# Step 3: If an object is identified, display a pop up screen
import random
from PIL import Image

if planet_identified == "earth":
    roll = random.random()
    if roll < 0.2:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/earth1.png')
        image.show()
    elif roll > 0.2 and roll < 0.4:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/earth2.png')
        image.show()
    elif roll > 0.4 and roll < 0.6:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/earth3.png')
        image.show()
    elif roll > 0.6 and roll < 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/earth4.png')
        image.show()
    elif roll > 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/earth5.png')
        image.show()



elif planet_identified == "moon":
    roll = random.random()
    if roll < 0.2:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/moon1.png')
        image.show()
    elif roll > 0.2 and roll < 0.4:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/moon2.png')
        image.show()
    elif roll > 0.4 and roll < 0.6:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/moon3.png')
        image.show()
    elif roll > 0.6 and roll < 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/moon4.png')
        image.show()
    elif roll > 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/moon5.png')
        image.show()



elif planet_identified == "mars":
    roll = random.random()
    if roll < 0.2:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/mars1.png')
        image.show()
    elif roll > 0.2 and roll < 0.4:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/mars2.png')
        image.show()
    elif roll > 0.4 and roll < 0.6:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/mars3.png')
        image.show()
    elif roll > 0.6 and roll < 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/mars4.png')
        image.show()
    elif roll > 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/mars5.png')
        image.show()



elif planet_identified == "jupiter":
    roll = random.random()
    if roll < 0.2:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/jupiter1.png')
        image.show()
    elif roll > 0.2 and roll < 0.4:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/jupiter2.png')
        image.show()
    elif roll > 0.4 and roll < 0.6:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/jupiter3.png')
        image.show()
    elif roll > 0.6 and roll < 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/jupiter4.png')
        image.show()
    elif roll > 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/jupiter5.png')
        image.show()



elif planet_identified == "saturn":
    roll = random.random()
    if roll < 0.2:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/saturn1.png')
        image.show()
    elif roll > 0.2 and roll < 0.4:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/saturn2.png')
        image.show()
    elif roll > 0.4 and roll < 0.6:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/saturn3.png')
        image.show()
    elif roll > 0.6 and roll < 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/saturn4.png')
        image.show()
    elif roll > 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/saturn5.png')
        image.show()



elif planet_identified == "uranus":
    roll = random.random()
    if roll < 0.2:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/uranus1.png')
        image.show()
    elif roll > 0.2 and roll < 0.4:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/uranus2.png')
        image.show()
    elif roll > 0.4 and roll < 0.6:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/uranus3.png')
        image.show()
    elif roll > 0.6 and roll < 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/uranus4.png')
        image.show()
    elif roll > 0.8:
        image = Image.open('C:/Users/Dotda/Pictures/Planeta Slides/uranus5.png')
        image.show()