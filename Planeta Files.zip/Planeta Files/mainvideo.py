# Step 1: Take input from camera
#import cv2
#vid = cv2.VideoCapture(0)

#while(True):

    # Capture the video frame by frame
    #ret, frame = vid.read()

    # Display the resulting frame
    #cv2.imshow('Planeta', frame)

    # the 'q' button is set as the quitting button you may use any desire button of your choice
    #if cv2.waitKey(1) & 0xFF == ord('q'):
        #break

# After the loop release the cap object
#vid.release()

# Destroy all the windows
#cv2.destroyAllWindows()












# Step 2: Look for objects in the camera using machine learning
from imageai.Detection.Custom import CustomVideoObjectDetection
import os

execution_path = os.getcwd()

detector = CustomVideoObjectDetection()
detector.setModelTypeAsYOLOv3()
detector.setModelPath("C:/Users/Dotda/PycharmProjects/Planeta/detection_model-ex-019--loss-0015.672.h5")
detector.setJsonPath( "C:/Users/Dotda/PycharmProjects/Planeta/detection_configearth.json")
detector.loadModel()

detector.detectObjectsFromVideo(input_file_path="C:/Users/Dotda/PycharmProjects/Planeta/earthtest.mp4", output_file_path=os.path.join(execution_path, "earthvideo.mp4"), frames_per_second=60, minimum_percentage_probability=65, log_progress=True)

#for detection in detections:
    #print(detection["name"], + " : ", detection["percentage_probability"], " : ", detection["box_points"])
#while(True):

    # Capture the video frame by frame
    #ret, frame = vid.read()
    #camera_input=vid
    #detections = detector.detectObjectsFromVideo(input_file_path=os.path.join(execution_path, "earthtest.mp4"), output_file_path=os.path.join(execution_path, "earthtestfinished"), frames_per_second=20, log_progress=True, minimum_percentage_probability=30)

#print(detections)

















# Step 3: If an object is identified, display a pop up screen
#import random
#from PIL import Image

#while planet_identified == "earth":
    #roll = random.random()
    #if roll < 0.2:
        #image = Image.open('earth1.png')
        #image.show()
    #elif roll > 0.2 and roll < 0.4:
        #image = Image.open('earth2.png')
        #image.show()
    #elif roll > 0.4 and roll < 0.6:
        #image = Image.open('earth3.png')
        #image.show()
    #elif roll > 0.6 and roll < 0.8:
        #image = Image.open('earth4.png')
        #image.show()
    #elif roll > 0.8:
        #image = Image.open('earth5.png')
        #image.show()



#while planet_identified == "moon":
    #roll = random.random()
    #if roll < 0.2:
        #image = Image.open('moon1.png')
        #image.show()
    #elif roll > 0.2 and roll < 0.4:
        #image = Image.open('moon2.png')
        #image.show()
    #elif roll > 0.4 and roll < 0.6:
        #image = Image.open('moon3.png')
        #image.show()
    #elif roll > 0.6 and roll < 0.8:
        #image = Image.open('moon4.png')
        #image.show()
    #elif roll > 0.8:
        #image = Image.open('moon5.png')
        #image.show()



#while planet_identified == "mars":
    #roll = random.random()
    #if roll < 0.2:
        #image = Image.open('mars1.png')
        #image.show()
    #elif roll > 0.2 and roll < 0.4:
        #image = Image.open('mars2.png')
        #image.show()
    #elif roll > 0.4 and roll < 0.6:
        #image = Image.open('mars3.png')
        #image.show()
    #elif roll > 0.6 and roll < 0.8:
        #image = Image.open('mars4.png')
        #image.show()
    #elif roll > 0.8:
        #image = Image.open('mars5.png')
        #image.show()



#while planet_identified == "jupiter":
    #roll = random.random()
    #if roll < 0.2:
        #image = Image.open('jupiter1.png')
        #image.show()
    #elif roll > 0.2 and roll < 0.4:
        #image = Image.open('jupiter2.png')
        #image.show()
    #elif roll > 0.4 and roll < 0.6:
        #image = Image.open('jupiter3.png')
        #image.show()
    #elif roll > 0.6 and roll < 0.8:
        #image = Image.open('jupiter4.png')
        #image.show()
    #elif roll > 0.8:
        #image = Image.open('jupiter5.png')
        #image.show()



#while planet_identified == "saturn":
    #roll = random.random()
    #if roll < 0.2:
        #image = Image.open('saturn1.png')
        #image.show()
    #elif roll > 0.2 and roll < 0.4:
        #image = Image.open('saturn2.png')
        #image.show()
    #elif roll > 0.4 and roll < 0.6:
        #image = Image.open('saturn3.png')
        #image.show()
    #elif roll > 0.6 and roll < 0.8:
        #image = Image.open('saturn4.png')
        #image.show()
    #elif roll > 0.8:
        #image = Image.open('saturn5.png')
        #image.show()



#while planet_identified == "uranus":
    #roll = random.random()
    #if roll < 0.2:
        #image = Image.open('uranus1.png')
        #image.show()
    #elif roll > 0.2 and roll < 0.4:
        #image = Image.open('uranus2.png')
        #image.show()
    #elif roll > 0.4 and roll < 0.6:
        #image = Image.open('uranus3.png')
        #image.show()
    #elif roll > 0.6 and roll < 0.8:
        #image = Image.open('uranus4.png')
        #image.show()
    #elif roll > 0.8:
        #image = Image.open('uranus5.png')
        #image.show()