from imageai.Detection.Custom import DetectionModelTrainer

trainer = DetectionModelTrainer()
trainer.setModelTypeAsYOLOv3()
trainer.setDataDirectory(data_directory="D:/Downloads/planet trainers/Earth")
trainer.setTrainConfig(object_names_array=["earth", "mars", "moon", "saturn", "jupiter", "uranus"], batch_size=6, num_experiments=100)
trainer.trainModel()